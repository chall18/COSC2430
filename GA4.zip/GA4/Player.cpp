//
// Created by Caitie Hall on 2/13/18.
//

#include "Player.h"
#include <iostream>
using namespace std;

Player::Player()
{
    number, age, min = 0;
}
void Player::setNumber(int newNum)
{
    number = newNum;
}
void Player::setAge(int newAge)
{
    age = newAge;
}
int Player::getNumber()
{
    return number;
}
int Player::getAge()
{
    return age;
}
double Player::getMin()
{
    return min;
}