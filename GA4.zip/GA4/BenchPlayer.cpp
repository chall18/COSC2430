//
// Created by Caitie Hall on 2/13/18.
//

#include "BenchPlayer.h"
#include <iostream>
using namespace std;
node *makeNewNode(Player info)
{
    //Good idea to write a separate fxn rather than constantly repeat
    //But we'll probably have to get more specific since each node has 3 attributes to it
    node *temp = new node;//creates node in dynamic memory
    temp->stats = info;
    temp->prev = NULL;
    temp->next = NULL;
    return temp;
}
void BenchPlayer::insertAtHead(Player info)
{
    node *newNode = makeNewNode(info);
    if(head == NULL)//If the list is empty, newNode is the head of the list and it's only node
    {
        head = newNode;
        return;
    }
    else
    {
        //If there are previously existing nodes
        head->prev = newNode;//The node behind head is now newNode, so we're setting that ptr to the address of newNode
        newNode->next = head;//Set next ptr of newNode to current head's address
        //I guess we don't say anything about newNode->prev b/c nothing's behind it yet?
        head = newNode;//...why?

    }
}
void BenchPlayer::insertAtTail(Player info)
{

}
void BenchPlayer::printList()
{

}
void BenchPlayer::reversePrint()
{

}