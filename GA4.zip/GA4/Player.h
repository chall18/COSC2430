//
// Created by Caitie Hall on 2/13/18.
//

#ifndef GA4_PLAYER_H
#define GA4_PLAYER_H
#include <iostream>
using namespace std;

class Player
{
private:
    int number, age;
    double min = age*.1;
public:
    Player();
    ~Player();
    void setNumber(int);
    void setAge(int);
    int getNumber();
    int getAge();
    double getMin();
};


#endif //GA4_PLAYER_H
