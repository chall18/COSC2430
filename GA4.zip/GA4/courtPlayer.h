//
// Created by Caitie Hall on 2/13/18.
//

/*
 Used the site below to help give me an idea of the structure of a circular LL.
http://www.sanfoundry.com/cpp-program-implement-circular-singly-linked-list/*/

#ifndef GA4_COURTPLAYER_H
#define GA4_COURTPLAYER_H
#include "Player.h"
#include <iostream>
using namespace std;
struct node
{
    int info;
    struct node *next;
}*last;
class courtPlayer:public Player
{
    //sorted circular linked list of players on court sorted by player num from center
public:
    void makeNode(int);
    void addAtHead(int);
    void addAtTail(int, int);
    void deleteNode(int);
    void searchNodes(int);
    void displayList();
    void updateList();
    void sortList();
    courtPlayer()
    {
        last = NULL;
    }


};


#endif //GA4_COURTPLAYER_H
