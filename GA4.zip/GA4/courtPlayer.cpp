//
// Created by Caitie Hall on 2/13/18.
//

#include "courtPlayer.h"
#include <iostream>
using namespace std;

void courtPlayer::makeNode(int content)//I think I just constructed the circular LL?
{
    /*struct node *temp;//Make temporary node
    temp = new(struct node);//Using new means dynamic allocation?
    temp->info = content;//The info inside temp is set to whatever int gets passed to this fxn
    if(last == NULL)//If the content of the last node is 0/NULL, which it should be
    {
        last = temp;//Last's empty content is now the content of temp
        temp->next = last;//Pointer to temp?
    }
    else
    {
        temp->next = last->next;
        last->next = temp;
        last = temp;
    }*/



}
void courtPlayer::addAtHead(int content)
{
    if(last == NULL)
    {
        cout << "List is empty." << endl;
        return;
    }
    else
    {
        struct node *temp;
        temp = new(struct node);
        temp->info = content;
        temp->next = last->next;
        last->next = temp;

    }
}
void courtPlayer::addAtTail(int content, int pos)
{
    if(last == NULL)
    {
        cout << "List is empty." << endl;
    }
    else
    {
        struct node *temp, *s;
        s = last-> next;
        for(int i = 0; i < pos-1; i++)
        {
            s = s->next;
            if(s == last->next)
            {
                cout << "There are less than " << pos << " in the list." << endl;
            }
        }
        temp = new(struct node);
        temp->next = s->next;
        temp->info = content;
        s->next = temp;
        if(s == last)
        {
            last = temp;
        }
    }
}
void courtPlayer::sortList()
{
    struct node *s, *ptr;
    int temp;
    if(last == NULL)
    {
        cout << "You can't sort an empty list." << endl;
    }
    s = last->next;
    while(s != last)
    {
        ptr = s->next;
        while(ptr != last->next)
        {
            if(ptr != last->next)
            {
                if(s->info > ptr->info)
                {
                    temp = s->info;
                    s->info = ptr->info;
                    ptr->info = temp;
                }
            }
            else
            {
                break;
            }
            s = s->next;
        }
    }
}
void courtPlayer::displayList()
{

    //Just a basic idea of how to show the list.
    //We'll have to get more specific.
    struct node *var;
    if(last == NULL)
    {
        cout << "List is empty." << endl;
    }
    var = last->next;
    cout << "Circular Linked List:" << endl;
    while(var != last)
    {
        cout << var->info << "->";
        var = var->next;
    }
    cout << var->info << endl;
}