#include <iostream>
#include "Player.h"
#include "BenchPlayer.h"
#include "courtPlayer.h"
using namespace std;
int main()
{
    Player lockerRoom[12];
    srand(time(0));
    for(int i = 0; i < 12; i++)
    {
        lockerRoom[i].setNumber(i+1);//They'll each get a player # 1-12
        lockerRoom[i].setAge(18 + rand()%(40-18 +1));//Randomly set age from 18-40
        //minutes is already set up based on player's age. I shouldn't need to state anything here
    }
    //randomly choose 5 players to be moved into the circular LL in class courtPlayer
    //Every time time is up for a player, select a bench player from either side of the DLL and swap them out.





    /*General how to make a circular linked list

     in the addNode function:
     if(root == null)
     {
     root = node;
     root.nextNode = root;
     }
     else
     {
        current = root;
        while(current.nexTNode != root)
       {
            current = current.nextNode;
       }

     }

     If you're at the end of the LL, every last node will point to the root.


     */

    return 0;
}