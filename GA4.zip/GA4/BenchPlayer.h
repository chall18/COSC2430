//
// Created by Caitie Hall on 2/13/18.
//

#ifndef GA4_BENCHPLAYER_H
#define GA4_BENCHPLAYER_H
#include "Player.h"
#include <iostream>
using namespace std;
struct node
{
    Player stats;//I'm thinking this has to be player b/c we have multiple attributes to deal w/ per node
    node *next, *prev;
};
struct node *head;//global ptr to node. Can be accessed everywhere in all fxns.
class BenchPlayer:public Player
{
    //Unsorted doubly linked list of 7 players on bench
public:
    node *makeNewNode(Player);
    void insertAtHead(Player);
    void insertAtTail(Player);
    void printList();
    void reversePrint();
};


#endif //GA4_BENCHPLAYER_H
